// David Ciupei
// CS 261
// Assignment #4

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "hash.h"
#define _POSIX_C_SOURCE 200809L
#define MAX_WORD_SIZE 256



struct LList {                              // linked list
    int counter;                            // counter for the word
    char word[MAX_WORD_SIZE];               // word with the max word size
    struct LList *next;                     // pointer to the next word
};


char* getNextWord(FILE* fd){
    assert(fd != NULL);                     //checks if the file is not empty
    
    char ch;
    while ((ch = fgetc(fd)) != EOF) {       // this will get the next character from the file as long as it doesnt reach the end of the file
        if (isalnum(ch)) break;             // checks if the passed character is alphanumeric
        
        
    }
    if (ch == EOF)return NULL;              // if the character is the end of the file return null
    
    char wordBuffer[MAX_WORD_SIZE];         //array with the MAX_WORD_SIZE in the array
    int pos = 0;
    
    wordBuffer[pos++] = tolower(ch);        //changes each word in the file to lowercase letter
    
    while((ch = fgetc(fd)) != EOF){         //gets the character from the file
        if (isspace(ch) || pos >= MAX_WORD_SIZE - 1)break;  //if there is white space or if the word doesnt exceed 256
        
        if (isalnum(ch)){                   // if the passed character is alphanumeric
            wordBuffer[pos++] = tolower(ch); // changes the word to lowercase
        }
    }
    wordBuffer[pos] = '\0';                 // terminates the string from the list
    char* result = (char*) malloc(strlen(wordBuffer)+1); // allocates memory of the list of words and puts it in result /
    strcpy(result,wordBuffer);              // copies the wordbuffer array to the result
    
    return result;                          // returns the words
}



void addWord (struct LList **list, char * w) {
    assert (list);                          //checks to see if there is a list
    struct LList *temp = *list;             //sets a temporary pointer
    
    while (temp) {                          //while the temp is true
        if (strcmp(temp->word, w) == 0) {   // compares the temp word from LList to the word from the file to see if they are the same
            temp->counter+=1;               // increments the count by 1 if true
            return;
        }
        temp = temp->next;                  //increments to the next word in the list
    }
    
    temp = (struct LList *)malloc (sizeof(struct LList)); //allocates memory for the list with temp being the pointer
    temp->next = *list;                     //the next word of the temp is the next word pointed from the file
    strcpy(temp->word, w);                  //copies the temp word with the word being passed in
    temp->counter=1;                        //sets the count of the word that only occurs once to 1
    *list = temp;                           //the list pointer is set to the the temp
    return;
    
}


// the function that is passed through the hashapply method
void printTable(Node* node, int x){

    printf("Key: %s  Value: %d\n",node->key,(int)node->val);

}

int main(int argc, char* argv[]){
    if (argc < 2){
        fprintf(stderr, "Error: %s Expecting at least one filename.\n", argv[0]);
        exit(1);
    }
    
    char* fileWord;                       // a pointer to the word in the file
    void* value;                          // this will contain the value of the key
    HashTable* table = HashInit(10);      // initialize the hashtable with 10 buckets
    
    for (int i = 1; i < argc; i++) {
        FILE* fd = fopen(argv[i], "r");             //opens the file for reading
        if(fd == NULL) {
            fprintf(stderr, "Can't open file %s\n, argv[1]", argv[i]);      //if error prints out message
            exit(1);
        }
	if (fd != NULL){                         // if there is a file with content prints a message
	  printf ("File Exits!\n");
	  printf("Here is the contents:\n");
	  printf("\n");
	}
    while((fileWord = getNextWord(fd)) != NULL) {
            value = HashSearch(table, fileWord);           //searches for the key and returns the value
            if(value != NULL) {
                value++;
                HashInsert(table, fileWord, value);         //inserts the value found with the key in the table
            }
            else {
                HashInsert(table, fileWord, (int*) 1);      // if new the key will get a value of 1
            }
        }
            fclose(fd);
    }
    
    HashApply(table,printTable);        //passes through the hashapply to be printed
    HashFree(table);                    //frees the table
    
    return 0;
}

